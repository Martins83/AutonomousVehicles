To repeat the simulations whose results are in this folder with the same initial settings we used, you need to copy and paste the file "input_data.csv" (that you can find in each experiment folder) in the folder "includes" of the main project.

The simulation will provide the files "AVs_data.csv" and "people_data.csv" as result, reporting simulation data about AVs and people, respectively.

